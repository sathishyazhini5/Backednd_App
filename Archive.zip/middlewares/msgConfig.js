const nodemailer = require('nodemailer');
const smtpTransport = require('nodemailer-smtp-transport');
const qs = require('qs');
const axios = require('axios');

const sendOTPMail = async (email, verifycode) => {
    try {
        var mailData = `<!DOCTYPE html>
        <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="icon" href="https://heartinz.com/image/png/whiteBG_heartinz_favicon.png" type="image/png"/>
                <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&ampdisplay=swap" rel="stylesheet">
                <title>Heartinz - OTP Verification</title>
            </head>
            <body style="margin: 2em; padding: 0; background-color: #f2f3f8; font-family: Inter;">
                <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 8px rgba(0,0,0,0.1); text-align: center;">
                    <div style="padding: 10px; background-color: #f1f1f1; color: #ffffff;">
                        <img src="https://heartinz.com/image/png/heartinz-logo-red.png" alt="Nego Bill" style="width: 180px;">
                    </div>
                    <div style="padding: 20px;">
                        <div style="font-size: 24px; font-weight: 500; font-family: Inter;color: #333333; margin: 20px 0;">Account Verification</div>
                        <p style="color: #666666;">Thank you for using our service. To verify your account, please use the following One-Time Password (OTP):</p>
                        <div style="font-size: 24px; font-weight: 500; color: #333333; margin: 20px 0;">${verifycode}</div>
                        <p style="color: #666666;">This OTP is valid for a short period of time and is confidential. Please do not share it with anyone.</p>
                    </div>
                    <div style="padding: 10px; background-color: #f1f1f1; font-size: 14px; color: #666666;">
                        &copy; 2024 <span style="font-size: 14px; font-weight: 500; font-family: Inter;">www.heartinz.com</span>. All rights reserved.
                    </div>
                </div>
            </body>
        </html>`

        const transporter = nodemailer.createTransport(smtpTransport({
            host: "smtp-relay.gmail.com",
            port: 587,
            secure: false,
            service: "gmail",
            auth: {
                user: "admin@negopix.com",
                pass: "ncefxwcqpqioomuv"
            },
            tls: {
                rejectUnauthorized: false
            }
        }));

        const mailOptions = {
            from: '<no-reply@heartinz.com>',
            to: email.toString(),
            subject: 'Heartinz Account Verification',
            html: mailData,
        };

        const info = await transporter.sendMail(mailOptions);
        return true;
    } catch (error) {
        return false;
    }
};

module.exports = { sendOTPMail };
