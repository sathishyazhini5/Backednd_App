const client = require('../database/db');

const listConfreFilters = async () => {
    try {
        // Query for `estatus.quickcode_mst` data
        const queryQuickCode = `
            SELECT json_build_object(
                'destyp', COALESCE(ARRAY_AGG(
                    json_build_object(
                        'quick_code', quick_code,
                        'quickcode_name', quickcode_name,
                        'language_code', quickcode_mst.language_code,
                        'concurrency_val', concurrency_val,
                        'created_by', created_by,
                        'created_date', created_date
                    )
                ) FILTER (WHERE quick_code_type = 'destyp'), '{}'),
                'divtyp', COALESCE(ARRAY_AGG(
                    json_build_object(
                        'quick_code', quick_code,
                        'quickcode_name', quickcode_name,
                        'language_code', quickcode_mst.language_code,
                        'concurrency_val', concurrency_val,
                        'created_by', created_by,
                        'created_date', created_date
                    )
                ) FILTER (WHERE quick_code_type = 'divtyp'), '{}'),
                'memtyp', COALESCE(ARRAY_AGG(
                    json_build_object(
                        'quick_code', quick_code,
                        'quickcode_name', quickcode_name,
                        'language_code', quickcode_mst.language_code,
                        'concurrency_val', concurrency_val,
                        'created_by', created_by,
                        'created_date', created_date
                    )
                ) FILTER (WHERE quick_code_type = 'memtyp'), '{}'),
                'natlty', COALESCE(ARRAY_AGG(
                    json_build_object(
                        'quick_code', quick_code,
                        'quickcode_name', quickcode_name,
                        'language_code', quickcode_mst.language_code,
                        'concurrency_val', concurrency_val,
                        'created_by', created_by,
                        'created_date', created_date
                    )
                ) FILTER (WHERE quick_code_type = 'natlty'), '{}')
            ) AS grouped_data
            FROM estatus.quickcode_mst quickcode_mst
        `;

        // Query for `estatus.division_setup_mst` grouped by `divtyp`
        const queryDivision = `
            SELECT division_type_code, json_agg(
                json_build_object(
                    'province_code', province_code,
                    'division_code', division_code,
                    'division_name', division_name,
                    'language_code', language_code,
                    'concurrency_val', concurrency_val,
                    'created_by', created_by,
                    'created_date', created_date
                )
            ) AS divisions
            FROM estatus.division_setup_mst
            GROUP BY division_type_code
        `;

        // Query for other data
        const queryBloodGroup = `SELECT row_to_json(bloodgroup_metadata) AS data FROM estatus.bloodgroup_metadata`;
        const queryLanguage = `SELECT row_to_json(languagemetadata) AS data FROM estatus.languagemetadata`;
        const queryProvince = `SELECT row_to_json(province_mst) AS data FROM estatus.province_mst`;

        // Execute all queries in parallel
        const [quickCodeResult, divisionResult, bloodGroupResult, languageResult, provinceResult] = await Promise.all([
            client.query(queryQuickCode),
            client.query(queryDivision),
            client.query(queryBloodGroup),
            client.query(queryLanguage),
            client.query(queryProvince)
        ]);

        // Map the divisions to the corresponding divtyp entry and ensure sorting
        const combinedResult = {
            ...quickCodeResult.rows[0].grouped_data,

            // Ensure divtyp is populated with sorted divisions
            divtyp: divisionResult.rows
                .map(row => {
                    // Find the corresponding divtyp entry by quick_code
                    const divtypEntry = quickCodeResult.rows[0].grouped_data.divtyp.find(
                        div => div.quick_code === row.division_type_code
                    );

                    const sortedDivisions = row.divisions.sort((a, b) => {
                        // Apply localeCompare to division_code if they are strings
                        return a.division_code.localeCompare(b.division_code);
                    });

                    return {
                        ...divtypEntry,
                        divisions: sortedDivisions
                    };
                })
                .sort((a, b) => a.quick_code.localeCompare(b.quick_code)), 

            // Mapping other results
            bloodgroup: bloodGroupResult.rows.map(row => row.data),
            language: languageResult.rows.map(row => row.data),
            province: provinceResult.rows.map(row => row.data)
        };

        return combinedResult;
    } catch (error) {
        throw error;
    }
};

const listCentreFilters = async () => {
    try {
        const queryQuickCode = `
            SELECT json_build_object(
                'divtyp', COALESCE(ARRAY_AGG(
                    json_build_object(
                        'quick_code', quick_code,
                        'quickcode_name', quickcode_name,
                        'language_code', quickcode_mst.language_code,
                        'concurrency_val', concurrency_val,
                        'created_by', created_by,
                        'created_date', created_date
                    )
                ) FILTER (WHERE quick_code_type = 'divtyp'), '{}'),
                'apostl', COALESCE(ARRAY_AGG(
                    json_build_object(
                        'quick_code', quick_code,
                        'quickcode_name', quickcode_name,
                        'language_code', quickcode_mst.language_code,
                        'concurrency_val', concurrency_val,
                        'created_by', created_by,
                        'created_date', created_date
                    )
                ) FILTER (WHERE quick_code_type = 'apostl'), '{}'),
                'ctrtyp', COALESCE(ARRAY_AGG(
                    json_build_object(
                        'quick_code', quick_code,
                        'quickcode_name', quickcode_name,
                        'language_code', quickcode_mst.language_code,
                        'concurrency_val', concurrency_val,
                        'created_by', created_by,
                        'created_date', created_date
                    )
                ) FILTER (WHERE quick_code_type = 'ctrtyp'), '{}'),

                'diocse', COALESCE(ARRAY_AGG(
                    json_build_object(
                        'quick_code', quick_code,
                        'quickcode_name', quickcode_name,
                        'language_code', quickcode_mst.language_code,
                        'concurrency_val', concurrency_val,
                        'created_by', created_by,
                        'created_date', created_date
                    )
                ) FILTER (WHERE quick_code_type = 'diocse'), '{}')
            ) AS grouped_data
            FROM estatus.quickcode_mst quickcode_mst
        `;

        // Query for `estatus.division_setup_mst` grouped by `divtyp`
        const queryDivision = `
            SELECT division_type_code, json_agg(
                json_build_object(
                    'province_code', province_code,
                    'division_code', division_code,
                    'division_name', division_name,
                    'language_code', language_code,
                    'concurrency_val', concurrency_val,
                    'created_by', created_by,
                    'created_date', created_date
                )
            ) AS divisions
            FROM estatus.division_setup_mst
            GROUP BY division_type_code
        `;

        // Query for other data
        const queryCommunityGroup = `SELECT row_to_json(community_house_dtl) AS data FROM estatus.community_house_dtl`;
        const queryLanguage = `SELECT row_to_json(languagemetadata) AS data FROM estatus.languagemetadata`;
        const queryProvince = `SELECT row_to_json(province_mst) AS data FROM estatus.province_mst`;
        const queryState = `SELECT row_to_json(state_mst) AS data FROM estatus.state_mst`;
        const queryCountry= `SELECT row_to_json(country_mst) AS data FROM estatus.country_mst`;

        // Execute all queries in parallel
        const [quickCodeResult, divisionResult, communityGroupResult, languageResult, provinceResult, stateResult, countryResult] = await Promise.all([
            client.query(queryQuickCode),
            client.query(queryDivision),
            client.query(queryCommunityGroup),
            client.query(queryLanguage),
            client.query(queryProvince),
            client.query(queryState),
            client.query(queryCountry)
        ]);

        // Map the divisions to the corresponding divtyp entry and ensure sorting
        const combinedResult = {
            ...quickCodeResult.rows[0].grouped_data,

            // Ensure divtyp is populated with sorted divisions
            divtyp: divisionResult.rows
                .map(row => {
                    // Find the corresponding divtyp entry by quick_code
                    const divtypEntry = quickCodeResult.rows[0].grouped_data.divtyp.find(
                        div => div.quick_code === row.division_type_code
                    );

                    const sortedDivisions = row.divisions.sort((a, b) => {
                        // Apply localeCompare to division_code if they are strings
                        return a.division_code.localeCompare(b.division_code);
                    });

                    return {
                        ...divtypEntry,
                        divisions: sortedDivisions
                    };
                })
                .sort((a, b) => a.quick_code.localeCompare(b.quick_code)), 

            // Mapping other results
            communitygroup: communityGroupResult.rows.map(row => row.data),
            language: languageResult.rows.map(row => row.data),
            province: provinceResult.rows.map(row => row.data),
            state: stateResult.rows.map(row => row.data),
            country: countryResult.rows.map(row => row.data)
        };

        return combinedResult;
    } catch (error) {
        throw error;
    }
};

const listObituaryFilters = async () => {
    try {
        const queryQuickCode = `
            SELECT json_build_object(
                'memtyp', COALESCE(
                    ARRAY_AGG(
                        json_build_object(
                            'quick_code', quick_code,
                            'quickcode_name', quickcode_name,
                            'language_code', quickcode_mst.language_code,
                            'concurrency_val', concurrency_val,
                            'created_by', created_by,
                            'created_date', created_date
                        )
                    ) FILTER (WHERE quick_code_type = 'memtyp'), '{}'
                )
            ) AS grouped_data
            FROM estatus.quickcode_mst quickcode_mst;
        `;

        // Query for other data
        const queryLanguage = `SELECT row_to_json(languagemetadata) AS data FROM estatus.languagemetadata`;
        const queryProvince = `SELECT row_to_json(province_mst) AS data FROM estatus.province_mst`;
        const queryCountry= `SELECT row_to_json(country_mst) AS data FROM estatus.country_mst`;

        // Execute all queries in parallel
        const [quickCodeResult, languageResult, provinceResult, countryResult] = await Promise.all([
            client.query(queryQuickCode),
            client.query(queryLanguage),
            client.query(queryProvince),
            client.query(queryCountry)
        ]);

        // Map the divisions to the corresponding divtyp entry and ensure sorting
        const combinedResult = {
            ...quickCodeResult.rows[0].grouped_data,
            language: languageResult.rows.map(row => row.data),
            province: provinceResult.rows.map(row => row.data),
            country: countryResult.rows.map(row => row.data)
        };

        return combinedResult;
    } catch (error) {
        throw error;
    }
};

module.exports = { listConfreFilters, listCentreFilters, listObituaryFilters };