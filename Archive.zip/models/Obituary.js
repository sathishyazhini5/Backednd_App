const client = require('../database/db');

const findObituary = async (provincecode, searchtxt, memtyp = 'ALL', languagecode = 'ALL', dcountry = 'ALL', ocountry = 'ALL', fromdate = '', todate = '') => {
    provincecode = provincecode || 'ALL';
    memtyp = memtyp || 'ALL';
    languagecode = languagecode || 'ALL';
    dcountry = dcountry || 'ALL';
    ocountry = ocountry || 'ALL';

    let query = `
        SELECT * FROM estatus.obituary_dtl
        WHERE ($1 = 'ALL' OR province_code = $1)
        AND (
            disease_name ILIKE $2
            OR death_place ILIKE $2
        )
        AND ($3 = 'ALL' OR member_type_code = $3)
        AND ($4 = 'ALL' OR death_country_code = $4)
        AND ($5 = 'ALL' OR orgin_country_code = $5)
        AND ($6 = 'ALL' OR language_code = $6)
    `;

    if (fromdate) {
        query += ` AND death_date >= $7`;
    }
    if (todate) {
        query += ` AND death_date <= $8`;
    }

    query += ` ORDER BY obituary_code ASC`;

    const params = [provincecode, `%${searchtxt}%`, memtyp, dcountry, ocountry, languagecode];
    if (fromdate) params.push(fromdate);
    if (todate) params.push(todate);

    try {
        const result = await client.query(query, params);
        return result.rows;
    } catch (error) {
        throw error;
    }
};

const findAnniversary = async (deathdate) => {
    try {
        const [, month, day] = deathdate.split('-');
        const query = `
            SELECT *
            FROM estatus.obituary_dtl
            WHERE TO_CHAR(death_date, 'MM-DD') = $1
            ORDER BY obituary_code ASC
        `;
        const params = [`${month}-${day}`];
        const result = await client.query(query, params);
        return result.rows;
    } catch (error) {
        throw error;
    }
};

module.exports = { findObituary, findAnniversary };