const client = require('../database/db');

const findConfreres = async (provincecode, searchtxt, memtyp = 'ALL', bloodgroup = 'ALL', natlty = 'ALL', languagecode = 'ALL') => {
    provincecode = provincecode || 'ALL';
    memtyp = memtyp || 'ALL';
    bloodgroup = bloodgroup || 'ALL';
    natlty = natlty || 'ALL';
    languagecode = languagecode || 'ALL';

    let query = `
        SELECT * FROM estatus.confreres_dtl
        WHERE ($1 = 'ALL' OR province_code = $1)
        AND (
            first_name ILIKE $2
            OR middle_name ILIKE $2
            OR last_name ILIKE $2
            OR personal1_contact_no::TEXT ILIKE $2
            OR personal2_contact_no::TEXT ILIKE $2
            OR personal3_contact_no::TEXT ILIKE $2
            OR watsup1_no::TEXT ILIKE $2
            OR personal_mailid1 ILIKE $2
        )
        AND ($3 = 'ALL' OR member_type_code = $3)
        AND ($4 = 'ALL' OR blood_group_code = $4)
        AND ($5 = 'ALL' OR nationality_code = $5)
        AND ($6 = 'ALL' OR language_code = $6)
        ORDER BY confrer_code ASC
    `;
    
    const params = [provincecode, `%${searchtxt}%`, memtyp, bloodgroup, natlty, languagecode];

    try {
        const result = await client.query(query, params);
        return result.rows;
    } catch (error) {
        throw error;
    }
};

const findCentres = async (provincecode, searchtxt, divtyp = 'ALL', apostl = 'ALL', ctrtyp = 'ALL', diocse = 'ALL', communitygroup = 'ALL', language = 'ALL', state = 'ALL', country = 'ALL') => {
    provincecode = provincecode || 'ALL';
    searchtxt = searchtxt ? `%${searchtxt}%` : '%';
    divtyp = divtyp || 'ALL';
    apostl = apostl || 'ALL';
    ctrtyp = ctrtyp || 'ALL';
    diocse = diocse || 'ALL';
    communitygroup = communitygroup || 'ALL';
    language = language || 'ALL';
    state = state || 'ALL';
    country = country || 'ALL';

    const query = `
        SELECT * FROM estatus.centre_dtl
        WHERE ($1 = 'ALL' OR province_code = $1)
        AND (
            centre_name ILIKE $2
            OR centre_place ILIKE $2
            OR city_dist ILIKE $2
            OR pin_zipcode::TEXT ILIKE $2
            OR phone1_no::TEXT ILIKE $2
            OR phone2_no::TEXT ILIKE $2
            OR phone3_no::TEXT ILIKE $2
            OR watsup_no::TEXT ILIKE $2
            OR office_mailid1 ILIKE $2
            OR office_mailid2 ILIKE $2
            OR website1 ILIKE $2
        )
        AND ($3 = 'ALL' OR division_type_code = $3)
        AND ($4 = 'ALL' OR apostolate_code = $4)
        AND ($5 = 'ALL' OR centre_type_code = $5)
        AND ($6 = 'ALL' OR community_house_code = $6)
        AND ($7 = 'ALL' OR country_code = $7)
        AND ($8 = 'ALL' OR state_code = $8)
        AND ($9 = 'ALL' OR diocese_code = $9)
        AND ($10 = 'ALL' OR language_code = $10)
        ORDER BY centre_code ASC
    `;

    const params = [provincecode, searchtxt, divtyp, apostl, ctrtyp, communitygroup, country, state, diocse, language];

    try {
        const result = await client.query(query, params);
        return result.rows;
    } catch (error) {
        throw error;
    }
};

const viewConfre = async (confrercode) => {
    const query = `SELECT * FROM estatus.confreres_dtl WHERE confrer_code = $1`;
    const params = [confrercode];
    try {
        // Fetch confrere details
        const result = await client.query(query, params);
        const confrer = result.rows[0];
        const { confrer_code, province_code, member_type_code } = confrer;

        // Fetch province details
        const query1 = `SELECT * FROM estatus.province_mst WHERE province_code = $1`;
        const params1 = [province_code];
        const result1 = await client.query(query1, params1);

        // Fetch member type details
        const query2 = `SELECT * FROM estatus.quickcode_mst WHERE quick_code = $1`;
        const params2 = [member_type_code];
        const result2 = await client.query(query2, params2);

        // Fetch appointment/transfer details
        const query3 = `SELECT * FROM estatus.appoint_transfer_dtl WHERE confrer_code = $1`;
        const params3 = [confrercode];
        const result3 = await client.query(query3, params3);
        if(result3.rows[0]) {
            const { designation_code } = result3.rows[0];
            const query4 = `SELECT * FROM estatus.quickcode_mst WHERE quick_code = $1`;
            const params4 = [designation_code];
            const result4 = await client.query(query4, params4);
            var designationdata = result4.rows[0];
        } else {
            var designationdata = {};
        }
        

        // Combine all the data into a single return object, including the designation under centre_code
        return {
            ...confrer, // Spread the entire confrer object, which includes all its fields
            province_code: result1.rows[0], // Add province details
            member_type_code: result2.rows[0], // Add member type details
            centre_code: {
                ...confrer,  // Spread the entire confrer object into centre_code
                designation_code: designationdata  // Add the designation_code under centre_code
            }
        };

    } catch (error) {
        throw error;
    }
};

const viewCentre = async (centrecode) => {
    const query = ` SELECT * FROM estatus.centre_dtl WHERE centre_code = $1`;
    const params = [centrecode];

    try {
        // Fetch centre data
        const result = await client.query(query, params);
        const centredata = result.rows[0];

        // Fetch appoint transfer data
        const query1 = ` SELECT * FROM estatus.appoint_transfer_dtl WHERE centre_code = $1`;
        const params1 = [centrecode];
        const result1 = await client.query(query1, params1);

        // Combine the data into the output without the `centredata` wrapper
        return {
            ...centredata,           // Add centre data properties directly
            confrer_data: result1.rows,  // Add the confrer data as a property
        };

    } catch (error) {
        throw error;
    }
};


module.exports = { findConfreres, findCentres, viewConfre, viewCentre};