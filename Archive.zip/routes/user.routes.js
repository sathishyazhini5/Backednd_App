const express = require('express');
const router = express.Router();
const { authUser } = require('../models/User');
const { check, validationResult } = require('express-validator');
const { sendOTPMail } = require("../middlewares/msgConfig");
const authAccessToken = require("../middlewares/authAccessToken");
const authRefreshToken = require("../middlewares/authRefreshToken");
const authVerifyToken = require("../middlewares/authVerifyToken");
const jwt = require('jsonwebtoken');

router.post("/auth-email", [
    check('email')
        .not()
        .isEmpty()
        .withMessage('The email is required and should not be empty.')
    ], async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        const firstError = errors.array()[0];
        return res.status(422).json({
            status: false,
            statuscode: 422,
            code: "VALIDATION_ERROR",
            message: "The request cannot be processed due to validation errors.",
            results: firstError
        });
    }
    try {
        var email=req.body.email;
        const checkUser = await authUser(email); 
        if (!checkUser) {
            return res.status(404).json({ status: false, statuscode:404, code:'NOT_FOUND', message: 'The requested user resource could not be found.', results: null });
        } else {
            var verifyotp = '123456';
            const mailResp = await sendOTPMail(email, verifyotp);
            if (mailResp) {
                const payload = { email: email, verifyotp: verifyotp };
                const token = jwt.sign(payload, process.env.OTP_SECRET_KEY, { expiresIn: process.env.OTP_EXPIRE });
                return res.status(201).json({
                    status: true,
                    statuscode: 201,
                    code: 'CREATED',
                    message: "Created. OTP successfully sent to your entered email.",
                    results: { verifytoken: token }
                });
            } else {
                return res.status(500).json({
                    status: false,
                    statuscode: 500,
                    code: "MAIL_SENDING_FAILED",
                    message: "An internal error occurred while sending the email.",
                    results: null
                });
            }
        }  
    } catch (error) {
        console.log(error)
        return res.status(500).json({ status: false, statuscode:500, message: "Internal Server Error. An internal error occurred in server", results:error});
    }
});

router.post("/auth-otp", [
    check('verifycode')
        .notEmpty()
        .withMessage('The OTP is required and should not be empty.')
        .isNumeric()
        .withMessage('The OTP should be a numeric value.')
        .isLength({ min: 6, max: 6 })
        .withMessage('Please enter a valid 6-digit OTP.')
], authVerifyToken, async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        const firstError = errors.array()[0];
        return res.status(422).json({
            status: false,
            statuscode: 422,
            code: "VALIDATION_ERROR",
            message: "The request cannot be processed due to validation errors.",
            results: firstError
        });
    }
    const { email, verifyotp } = req.authOtp;
    const verifycode = req.body.verifycode;
    try {
        const checkUser = await authUser(email); 
        if (!checkUser) {
            return res.status(404).json({ status: false, statuscode:404, code:'NOT_FOUND', message: 'The requested user resource could not be found.', results: null });
        } else {
            if(verifyotp == verifycode && email == checkUser.personal_mailid1) {
                const userData = {
                    usercode : checkUser.confrer_code,
                    email: checkUser.personal_mailid1
                };

                const accessToken = jwt.sign(
                    userData, process.env.ACCESS_SECRET_AKEY,
                    { expiresIn: process.env.ACCESS_AEXPIRE }
                );

                const refreshToken = jwt.sign(
                    userData, process.env.REFRESH_SECRET_AKEY,
                    { expiresIn: process.env.REFRESH_AEXPIRE }
                );
                return res.status(201).json({
                    status: true,
                    statuscode: 201,
                    code: 'VERIFIED',
                    message: "Token verified, Login Successfully",
                    results: {
                        accessToken: accessToken,
                        refreshToken: refreshToken
                    }
                });
            } else {    
                return res.status(401).send({
                    status: false,
                    statuscode: 401,
                    code: 'OTP_VERIFY_FAILURE',
                    message: 'OTP verification failed. Please retry with the correct OTP.',
                    results: null
                });
            }
        }
    } catch (error) {
        return res.status(500).json({
            status: false,
            statuscode: 500,
            code: 'INTERNAL_SERVER_ERROR',
            message: "Internal Server Error. An internal error occurred in the server.",
            results: error
        });
    }
});

router.get("/auth-token", authAccessToken, (req, res) => {
    return res.status(200).json({
        status: true,
        statuscode: 200,
        code:'VERIFIED',
        message: "Token verified successfully.",
        results: req.authuser
    });
});

router.get("/create-token", authRefreshToken, (req, res) => {
    return res.status(201).json({
        status: true,
        statuscode: 201,
        code: 'VERIFIED',
        message: "Token verified, Login Successfully",
        results: {
            accessToken: req.authtoken
        }
    });
});

const generateOtp = async() => {
    const expiration = new Date();
    expiration.setMinutes(expiration.getMinutes() + 3);
    return Math.floor(100000 + Math.random() * 900000).toString();
}

module.exports = router;
